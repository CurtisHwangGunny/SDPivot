--
-- PostgreSQL database dump
--

\restrict XLZcNv5Uc05T9mcl0cFXGPO27PJfolHG3UKapG6pzbXPKswqRNYiwJHW2fXyXjv

-- Dumped from database version 17.9 (Debian 17.9-1.pgdg13+1)
-- Dumped by pg_dump version 17.9 (Debian 17.9-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP POLICY IF EXISTS tenant_isolation ON public.token_usage;
DROP POLICY IF EXISTS tenant_isolation ON public.space_categories;
DROP POLICY IF EXISTS tenant_isolation ON public.org_ext;
DROP POLICY IF EXISTS tenant_isolation ON public.knowledge_spaces;
ALTER TABLE IF EXISTS ONLY public.token_usage DROP CONSTRAINT IF EXISTS token_usage_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.token_usage DROP CONSTRAINT IF EXISTS token_usage_org_id_fkey;
ALTER TABLE IF EXISTS ONLY public.space_members DROP CONSTRAINT IF EXISTS space_members_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.space_members DROP CONSTRAINT IF EXISTS space_members_space_id_fkey;
ALTER TABLE IF EXISTS ONLY public.refresh_tokens DROP CONSTRAINT IF EXISTS refresh_tokens_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.organizations DROP CONSTRAINT IF EXISTS organizations_owner_id_fkey;
ALTER TABLE IF EXISTS ONLY public.org_members DROP CONSTRAINT IF EXISTS org_members_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.org_members DROP CONSTRAINT IF EXISTS org_members_org_id_fkey;
ALTER TABLE IF EXISTS ONLY public.knowledge_spaces DROP CONSTRAINT IF EXISTS knowledge_spaces_org_id_fkey;
ALTER TABLE IF EXISTS ONLY public.knowledge_spaces DROP CONSTRAINT IF EXISTS knowledge_spaces_creator_id_fkey;
DROP INDEX IF EXISTS public.idx_users_username;
DROP INDEX IF EXISTS public.idx_users_status;
DROP INDEX IF EXISTS public.idx_users_phone;
DROP INDEX IF EXISTS public.idx_users_ops_admin;
DROP INDEX IF EXISTS public.idx_users_email;
DROP INDEX IF EXISTS public.idx_token_usage_user_created;
DROP INDEX IF EXISTS public.idx_token_usage_tenant_created;
DROP INDEX IF EXISTS public.idx_token_usage_org_created;
DROP INDEX IF EXISTS public.idx_space_categories_tenant_id;
DROP INDEX IF EXISTS public.idx_sknp_user_id;
DROP INDEX IF EXISTS public.idx_sknp_status;
DROP INDEX IF EXISTS public.idx_sknp_phone;
DROP INDEX IF EXISTS public.idx_refresh_tokens_user_id;
DROP INDEX IF EXISTS public.idx_refresh_tokens_token_hash;
DROP INDEX IF EXISTS public.idx_refresh_tokens_expires_at;
DROP INDEX IF EXISTS public.idx_org_ext_tenant_id;
DROP INDEX IF EXISTS public.idx_org_ext_auth_status;
DROP INDEX IF EXISTS public.idx_knowledge_spaces_tenant_id;
DROP INDEX IF EXISTS public.idx_knowledge_spaces_org_id;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_pkey;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_phone_key;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_email_key;
ALTER TABLE IF EXISTS ONLY public.token_usage DROP CONSTRAINT IF EXISTS token_usage_pkey;
ALTER TABLE IF EXISTS ONLY public.space_members DROP CONSTRAINT IF EXISTS space_members_space_id_user_id_key;
ALTER TABLE IF EXISTS ONLY public.space_members DROP CONSTRAINT IF EXISTS space_members_pkey;
ALTER TABLE IF EXISTS ONLY public.space_categories DROP CONSTRAINT IF EXISTS space_categories_pkey;
ALTER TABLE IF EXISTS ONLY public.smartknora_user_profiles DROP CONSTRAINT IF EXISTS smartknora_user_profiles_user_id_key;
ALTER TABLE IF EXISTS ONLY public.smartknora_user_profiles DROP CONSTRAINT IF EXISTS smartknora_user_profiles_pkey;
ALTER TABLE IF EXISTS ONLY public.smartknora_user_profiles DROP CONSTRAINT IF EXISTS smartknora_user_profiles_phone_key;
ALTER TABLE IF EXISTS ONLY public.refresh_tokens DROP CONSTRAINT IF EXISTS refresh_tokens_token_hash_key;
ALTER TABLE IF EXISTS ONLY public.refresh_tokens DROP CONSTRAINT IF EXISTS refresh_tokens_pkey;
ALTER TABLE IF EXISTS ONLY public.organizations DROP CONSTRAINT IF EXISTS organizations_pkey;
ALTER TABLE IF EXISTS ONLY public.organizations DROP CONSTRAINT IF EXISTS organizations_name_key;
ALTER TABLE IF EXISTS ONLY public.organizations DROP CONSTRAINT IF EXISTS organizations_invite_code_key;
ALTER TABLE IF EXISTS ONLY public.org_members DROP CONSTRAINT IF EXISTS org_members_pkey;
ALTER TABLE IF EXISTS ONLY public.org_members DROP CONSTRAINT IF EXISTS org_members_org_id_user_id_key;
ALTER TABLE IF EXISTS ONLY public.org_ext DROP CONSTRAINT IF EXISTS org_ext_pkey;
ALTER TABLE IF EXISTS ONLY public.knowledge_spaces DROP CONSTRAINT IF EXISTS knowledge_spaces_pkey;
DROP TABLE IF EXISTS public.users;
DROP TABLE IF EXISTS public.token_usage;
DROP TABLE IF EXISTS public.space_members;
DROP TABLE IF EXISTS public.space_categories;
DROP TABLE IF EXISTS public.smartknora_user_profiles;
DROP TABLE IF EXISTS public.refresh_tokens;
DROP TABLE IF EXISTS public.organizations;
DROP TABLE IF EXISTS public.org_members;
DROP TABLE IF EXISTS public.org_ext;
DROP TABLE IF EXISTS public.knowledge_spaces;
DROP FUNCTION IF EXISTS public.set_tenant_context(p_tenant_id uuid);
DROP EXTENSION IF EXISTS vector;
DROP EXTENSION IF EXISTS postgis_topology;
DROP EXTENSION IF EXISTS postgis_tiger_geocoder;
DROP EXTENSION IF EXISTS postgis;
DROP EXTENSION IF EXISTS pg_stat_statements;
DROP EXTENSION IF EXISTS fuzzystrmatch;
DROP SCHEMA IF EXISTS topology;
DROP SCHEMA IF EXISTS tiger;
DROP EXTENSION IF EXISTS pg_ivm;
DROP EXTENSION IF EXISTS pg_search;
DROP SCHEMA IF EXISTS paradedb;
--
-- Name: paradedb; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA paradedb;


ALTER SCHEMA paradedb OWNER TO postgres;

--
-- Name: pg_search; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_search WITH SCHEMA paradedb;


--
-- Name: EXTENSION pg_search; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pg_search IS 'pg_search: Full text search for PostgreSQL using BM25';


--
-- Name: pg_ivm; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_ivm WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION pg_ivm; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pg_ivm IS 'incremental view maintenance on PostgreSQL';


--
-- Name: tiger; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA tiger;


ALTER SCHEMA tiger OWNER TO postgres;

--
-- Name: topology; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA topology;


ALTER SCHEMA topology OWNER TO postgres;

--
-- Name: SCHEMA topology; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA topology IS 'PostGIS Topology schema';


--
-- Name: fuzzystrmatch; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS fuzzystrmatch WITH SCHEMA public;


--
-- Name: EXTENSION fuzzystrmatch; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION fuzzystrmatch IS 'determine similarities and distance between strings';


--
-- Name: pg_stat_statements; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_stat_statements WITH SCHEMA public;


--
-- Name: EXTENSION pg_stat_statements; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pg_stat_statements IS 'track planning and execution statistics of all SQL statements executed';


--
-- Name: postgis; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS postgis WITH SCHEMA public;


--
-- Name: EXTENSION postgis; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION postgis IS 'PostGIS geometry and geography spatial types and functions';


--
-- Name: postgis_tiger_geocoder; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS postgis_tiger_geocoder WITH SCHEMA tiger;


--
-- Name: EXTENSION postgis_tiger_geocoder; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION postgis_tiger_geocoder IS 'PostGIS tiger geocoder and reverse geocoder';


--
-- Name: postgis_topology; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS postgis_topology WITH SCHEMA topology;


--
-- Name: EXTENSION postgis_topology; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION postgis_topology IS 'PostGIS topology spatial types and functions';


--
-- Name: vector; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS vector WITH SCHEMA public;


--
-- Name: EXTENSION vector; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION vector IS 'vector data type and ivfflat and hnsw access methods';


--
-- Name: set_tenant_context(uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.set_tenant_context(p_tenant_id uuid) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
BEGIN
    PERFORM set_config('app.current_tenant_id', p_tenant_id::TEXT, false);
END;
$$;


ALTER FUNCTION public.set_tenant_context(p_tenant_id uuid) OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: knowledge_spaces; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.knowledge_spaces (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id integer NOT NULL,
    org_id uuid,
    name character varying(255) NOT NULL,
    description text,
    visibility character varying(20) DEFAULT 'team'::character varying NOT NULL,
    icon character varying(50),
    creator_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);


ALTER TABLE public.knowledge_spaces OWNER TO postgres;

--
-- Name: org_ext; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.org_ext (
    org_id uuid NOT NULL,
    auth_status character varying(20) DEFAULT 'trial'::character varying NOT NULL,
    auth_type character varying(20),
    auth_expires_at timestamp with time zone,
    tenant_id bigint NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.org_ext OWNER TO postgres;

--
-- Name: org_members; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.org_members (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    org_id uuid NOT NULL,
    user_id uuid NOT NULL,
    role character varying(20) DEFAULT 'member'::character varying NOT NULL,
    status character varying(20) DEFAULT 'active'::character varying NOT NULL,
    joined_at timestamp with time zone DEFAULT now() NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.org_members OWNER TO postgres;

--
-- Name: organizations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.organizations (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(255) NOT NULL,
    logo_url text,
    description text,
    auth_status character varying(20) DEFAULT 'trial'::character varying NOT NULL,
    auth_type character varying(20),
    auth_expires_at timestamp with time zone,
    config jsonb DEFAULT '{}'::jsonb,
    invite_code character varying(32),
    owner_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    avatar character varying(512),
    owner_tenant_id bigint DEFAULT 0,
    invite_code_expires_at timestamp with time zone,
    invite_code_validity_days integer DEFAULT 7,
    require_approval boolean DEFAULT false,
    searchable boolean DEFAULT false,
    member_limit integer DEFAULT 50,
    created_by character varying(36),
    plan character varying(50) DEFAULT 'free'::character varying
);


ALTER TABLE public.organizations OWNER TO postgres;

--
-- Name: refresh_tokens; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.refresh_tokens (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    token_hash character varying(64) NOT NULL,
    device_id character varying(255),
    family uuid NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.refresh_tokens OWNER TO postgres;

--
-- Name: smartknora_user_profiles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.smartknora_user_profiles (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying(36) NOT NULL,
    phone character varying(20),
    nickname character varying(100),
    status character varying(20) DEFAULT 'active'::character varying NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);


ALTER TABLE public.smartknora_user_profiles OWNER TO postgres;

--
-- Name: space_categories; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.space_categories (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id integer NOT NULL,
    name character varying(100) NOT NULL,
    color character varying(20),
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.space_categories OWNER TO postgres;

--
-- Name: space_members; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.space_members (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    space_id uuid NOT NULL,
    user_id uuid NOT NULL,
    role character varying(20) DEFAULT 'viewer'::character varying NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.space_members OWNER TO postgres;

--
-- Name: token_usage; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.token_usage (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid,
    org_id uuid,
    tenant_id integer NOT NULL,
    model_id character varying(64),
    prompt_tokens integer DEFAULT 0 NOT NULL,
    completion_tokens integer DEFAULT 0 NOT NULL,
    total_tokens integer DEFAULT 0 NOT NULL,
    api_path character varying(255),
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.token_usage OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    phone character varying(20),
    email character varying(255),
    password_hash character varying(255) NOT NULL,
    nickname character varying(100),
    avatar_url text,
    status character varying(20) DEFAULT 'active'::character varying NOT NULL,
    last_login_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    username character varying(100),
    avatar character varying(500),
    tenant_id bigint DEFAULT 1,
    is_active boolean DEFAULT true,
    can_access_all_tenants boolean DEFAULT false,
    is_system_admin boolean DEFAULT false,
    preferences jsonb DEFAULT '{}'::jsonb,
    is_ops_admin boolean DEFAULT false,
    must_change_password boolean DEFAULT false,
    password_changed_at timestamp with time zone,
    password_expires_at timestamp with time zone
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Data for Name: _typmod_cache; Type: TABLE DATA; Schema: paradedb; Owner: postgres
--

COPY paradedb._typmod_cache (id, typmod) FROM stdin;
\.


--
-- Data for Name: pg_ivm_immv; Type: TABLE DATA; Schema: pgivm; Owner: postgres
--

COPY pgivm.pg_ivm_immv (immvrelid, viewdef, ispopulated, lastivmupdate) FROM stdin;
\.


--
-- Data for Name: knowledge_spaces; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.knowledge_spaces (id, tenant_id, org_id, name, description, visibility, icon, creator_id, created_at, updated_at, deleted_at) FROM stdin;
649788db-adbb-43b8-9e94-4f1676ed0dda	1	\N	测试空间	sprint1 test	team		a966dac1-7bed-4529-8a9d-a0a3dfe9d452	2026-07-02 03:41:32.552834+00	2026-07-02 03:41:32.552834+00	\N
\.


--
-- Data for Name: org_ext; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.org_ext (org_id, auth_status, auth_type, auth_expires_at, tenant_id, created_at, updated_at) FROM stdin;
bdff1d71-c53d-4e1b-bfce-6756924a302f	trial		\N	1	2026-07-02 02:37:41.998224+00	2026-07-02 02:37:41.998224+00
\.


--
-- Data for Name: org_members; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.org_members (id, org_id, user_id, role, status, joined_at, created_at, updated_at) FROM stdin;
5036ed83-4411-4a9f-95df-9221e5eb0926	bdff1d71-c53d-4e1b-bfce-6756924a302f	a966dac1-7bed-4529-8a9d-a0a3dfe9d452	owner	active	2026-07-02 02:37:41.998224+00	2026-07-02 02:37:42.029498+00	2026-07-02 02:37:42.029498+00
\.


--
-- Data for Name: organizations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.organizations (id, name, logo_url, description, auth_status, auth_type, auth_expires_at, config, invite_code, owner_id, created_at, updated_at, deleted_at, avatar, owner_tenant_id, invite_code_expires_at, invite_code_validity_days, require_approval, searchable, member_limit, created_by, plan) FROM stdin;
bdff1d71-c53d-4e1b-bfce-6756924a302f	默认组织	\N		trial	\N	\N	{}		a966dac1-7bed-4529-8a9d-a0a3dfe9d452	2026-07-02 02:37:41.998224+00	2026-07-02 02:37:41.998224+00	\N		0	\N	7	f	f	50	\N	free
\.


--
-- Data for Name: refresh_tokens; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.refresh_tokens (id, user_id, token_hash, device_id, family, expires_at, created_at) FROM stdin;
9191494b-8b2e-4186-957c-8c5c026a6500	a966dac1-7bed-4529-8a9d-a0a3dfe9d452	9030c2a09f0bc05b5e5c5908473299fb03d901b61b81c765a9a72fdd22696f81		2a8dc4b9-deae-4d01-b894-a4f694688ea5	2026-07-09 02:37:41.980234+00	2026-07-02 02:37:41.980234+00
5099ba00-6450-435b-945c-434de32ae691	a966dac1-7bed-4529-8a9d-a0a3dfe9d452	80af9403bf4b6c521f82343b32203ba025e8460f919728b7c2b7947d5aa95461		f84eeaf4-c95a-4943-b01b-a526a89b932d	2026-07-09 02:38:04.414834+00	2026-07-02 02:38:04.414834+00
849f660e-624e-46f5-b418-beaf6158cafc	a966dac1-7bed-4529-8a9d-a0a3dfe9d452	355fbea8a2a518aaf35d58a2bc75dec73f71f7adb21867cea4d87100b977bfbd		cf775d8b-b02e-4738-91fb-88bdf8e8b722	2026-07-09 02:49:18.703058+00	2026-07-02 02:49:18.703058+00
e2d1cc18-833d-4d75-80ec-1520400fc21f	a966dac1-7bed-4529-8a9d-a0a3dfe9d452	0ee00f166a2687ff54df55dab30ea504301400d256297992cd6dc5e209a87945		232e380d-df26-495c-93e8-c4c7169c27bd	2026-07-09 02:55:46.288479+00	2026-07-02 02:55:46.288479+00
e1ce18af-fd85-4adb-8b64-f1f9aab9496e	a966dac1-7bed-4529-8a9d-a0a3dfe9d452	4dbc56e05e69c40761058ebf11cde9e699a76cfd352b3deff0dee0b293ab4b32		3c4928a6-3622-4a37-b721-1be098a22516	2026-07-09 03:14:31.192397+00	2026-07-02 03:14:31.192397+00
e5716531-9474-4ea8-b104-5960b83895ae	a966dac1-7bed-4529-8a9d-a0a3dfe9d452	55098fd1369ffdf1d015992c2cf4fb7acab92993a9077290d509abef61f648f1		8281b9c9-e26d-40a6-9652-73dae249ff9c	2026-07-09 03:28:54.852007+00	2026-07-02 03:28:54.852007+00
3c08c64c-f40f-43ad-af86-1414ab829ee0	a966dac1-7bed-4529-8a9d-a0a3dfe9d452	f8a4bcc3c22217a909584052b6fcb2cb2e75523f5320875d14ff158bd2338767		c431b5a0-ef11-4db0-921a-eb24264e1338	2026-07-09 03:34:42.213718+00	2026-07-02 03:34:42.213718+00
f7918106-df4f-4c8c-8482-9abcddbb57d9	a966dac1-7bed-4529-8a9d-a0a3dfe9d452	27c2bae4ee74877eca55132fea5e20a4fa828fbd09ccab544897956e21647910		347c0dab-bdc9-4fc8-9596-3f5071dbad2e	2026-07-09 03:40:42.194544+00	2026-07-02 03:40:42.194544+00
a26ced82-c361-416e-864c-0f8184f09362	a966dac1-7bed-4529-8a9d-a0a3dfe9d452	818c6b1b0f902781d9b6f626532057eba2f374bb13208b43a121f0114e028071		b8806ebc-1f13-4fb3-b0eb-5025e8a60c18	2026-07-09 03:57:46.012657+00	2026-07-02 03:57:46.012657+00
9b5d09d9-5bbc-4de9-a84c-15768ab91821	c4d04981-dc8f-404b-a029-bffa4e66721f	fda2938e5a693bfaa80b4876d2cbbacacc34ec15e3ddd89ac451e55c6e55def2		8b331e7f-e0f4-4baf-950c-6059397e135a	2026-07-09 04:03:11.027618+00	2026-07-02 04:03:11.027618+00
57de2ae2-b224-43af-a47c-197f380d0ba1	c4d04981-dc8f-404b-a029-bffa4e66721f	49e0ff8ea59804bb69b8f3b5bae875ee742c25491113a4c05e5c6a7f235e86d9		decc99e0-f35f-45ff-ad0c-2a122f222a45	2026-07-09 04:16:14.593404+00	2026-07-02 04:16:14.593404+00
1a89d6d2-4419-40c5-b63f-ec65a4e5760a	c4d04981-dc8f-404b-a029-bffa4e66721f	2677b6a7bfac9af75d96136611c5d01158b1e978ea91cfd9dd05f97dfa522d62		a5845700-baa1-42d0-b2ab-2fe84a7e91c7	2026-07-09 04:17:19.937747+00	2026-07-02 04:17:19.937747+00
\.


--
-- Data for Name: smartknora_user_profiles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.smartknora_user_profiles (id, user_id, phone, nickname, status, created_at, updated_at, deleted_at) FROM stdin;
c4ff166e-a5a3-4637-abc8-c0fc6ab8e148	a966dac1-7bed-4529-8a9d-a0a3dfe9d452		用户	active	2026-07-02 02:37:41.980234+00	2026-07-02 02:37:41.980234+00	\N
\.


--
-- Data for Name: space_categories; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.space_categories (id, tenant_id, name, color, created_at) FROM stdin;
\.


--
-- Data for Name: space_members; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.space_members (id, space_id, user_id, role, created_at) FROM stdin;
4ac6372b-c053-4791-af69-89cc83095e06	649788db-adbb-43b8-9e94-4f1676ed0dda	a966dac1-7bed-4529-8a9d-a0a3dfe9d452	owner	2026-07-02 03:41:32.552834+00
\.


--
-- Data for Name: spatial_ref_sys; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.spatial_ref_sys (srid, auth_name, auth_srid, srtext, proj4text) FROM stdin;
\.


--
-- Data for Name: token_usage; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.token_usage (id, user_id, org_id, tenant_id, model_id, prompt_tokens, completion_tokens, total_tokens, api_path, created_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, phone, email, password_hash, nickname, avatar_url, status, last_login_at, created_at, updated_at, deleted_at, username, avatar, tenant_id, is_active, can_access_all_tenants, is_system_admin, preferences, is_ops_admin, must_change_password, password_changed_at, password_expires_at) FROM stdin;
c4d04981-dc8f-404b-a029-bffa4e66721f	\N	sysadmin@smartknora.com	$2a$10$rGIJxIyWdJ4EeT3LJveldeUL3odV59vbn.A.vx13IukU0RPl/iaFW	\N	\N	active	\N	2026-07-02 04:03:11.027618+00	2026-07-02 04:17:19.937747+00	\N	sysadmin@smartknora.com		1	t	t	t	{}	f	f	\N	\N
a966dac1-7bed-4529-8a9d-a0a3dfe9d452	\N	admin@smartknora.com	$2a$10$L4fDCGy48S7wHDmzZqAAf.sql5NnA1.0uEwfbbVzvAsMSV0qyUGS2	\N	\N	active	\N	2026-07-02 02:37:41.980234+00	2026-07-02 03:57:46.012657+00	\N	admin@smartknora.com		1	t	f	f	{}	t	t	\N	\N
\.


--
-- Data for Name: geocode_settings; Type: TABLE DATA; Schema: tiger; Owner: postgres
--

COPY tiger.geocode_settings (name, setting, unit, category, short_desc) FROM stdin;
\.


--
-- Data for Name: pagc_gaz; Type: TABLE DATA; Schema: tiger; Owner: postgres
--

COPY tiger.pagc_gaz (id, seq, word, stdword, token, is_custom) FROM stdin;
\.


--
-- Data for Name: pagc_lex; Type: TABLE DATA; Schema: tiger; Owner: postgres
--

COPY tiger.pagc_lex (id, seq, word, stdword, token, is_custom) FROM stdin;
\.


--
-- Data for Name: pagc_rules; Type: TABLE DATA; Schema: tiger; Owner: postgres
--

COPY tiger.pagc_rules (id, rule, is_custom) FROM stdin;
\.


--
-- Data for Name: topology; Type: TABLE DATA; Schema: topology; Owner: postgres
--

COPY topology.topology (id, name, srid, "precision", hasz, useslargeids) FROM stdin;
\.


--
-- Data for Name: layer; Type: TABLE DATA; Schema: topology; Owner: postgres
--

COPY topology.layer (topology_id, layer_id, schema_name, table_name, feature_column, feature_type, level, child_id) FROM stdin;
\.


--
-- Name: _typmod_cache_id_seq; Type: SEQUENCE SET; Schema: paradedb; Owner: postgres
--

SELECT pg_catalog.setval('paradedb._typmod_cache_id_seq', 1, false);


--
-- Name: topology_id_seq; Type: SEQUENCE SET; Schema: topology; Owner: postgres
--

SELECT pg_catalog.setval('topology.topology_id_seq', 1, false);


--
-- Name: knowledge_spaces knowledge_spaces_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.knowledge_spaces
    ADD CONSTRAINT knowledge_spaces_pkey PRIMARY KEY (id);


--
-- Name: org_ext org_ext_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.org_ext
    ADD CONSTRAINT org_ext_pkey PRIMARY KEY (org_id);


--
-- Name: org_members org_members_org_id_user_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.org_members
    ADD CONSTRAINT org_members_org_id_user_id_key UNIQUE (org_id, user_id);


--
-- Name: org_members org_members_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.org_members
    ADD CONSTRAINT org_members_pkey PRIMARY KEY (id);


--
-- Name: organizations organizations_invite_code_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.organizations
    ADD CONSTRAINT organizations_invite_code_key UNIQUE (invite_code);


--
-- Name: organizations organizations_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.organizations
    ADD CONSTRAINT organizations_name_key UNIQUE (name);


--
-- Name: organizations organizations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.organizations
    ADD CONSTRAINT organizations_pkey PRIMARY KEY (id);


--
-- Name: refresh_tokens refresh_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.refresh_tokens
    ADD CONSTRAINT refresh_tokens_pkey PRIMARY KEY (id);


--
-- Name: refresh_tokens refresh_tokens_token_hash_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.refresh_tokens
    ADD CONSTRAINT refresh_tokens_token_hash_key UNIQUE (token_hash);


--
-- Name: smartknora_user_profiles smartknora_user_profiles_phone_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.smartknora_user_profiles
    ADD CONSTRAINT smartknora_user_profiles_phone_key UNIQUE (phone);


--
-- Name: smartknora_user_profiles smartknora_user_profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.smartknora_user_profiles
    ADD CONSTRAINT smartknora_user_profiles_pkey PRIMARY KEY (id);


--
-- Name: smartknora_user_profiles smartknora_user_profiles_user_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.smartknora_user_profiles
    ADD CONSTRAINT smartknora_user_profiles_user_id_key UNIQUE (user_id);


--
-- Name: space_categories space_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.space_categories
    ADD CONSTRAINT space_categories_pkey PRIMARY KEY (id);


--
-- Name: space_members space_members_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.space_members
    ADD CONSTRAINT space_members_pkey PRIMARY KEY (id);


--
-- Name: space_members space_members_space_id_user_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.space_members
    ADD CONSTRAINT space_members_space_id_user_id_key UNIQUE (space_id, user_id);


--
-- Name: token_usage token_usage_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.token_usage
    ADD CONSTRAINT token_usage_pkey PRIMARY KEY (id);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_phone_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_phone_key UNIQUE (phone);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: idx_knowledge_spaces_org_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_knowledge_spaces_org_id ON public.knowledge_spaces USING btree (org_id);


--
-- Name: idx_knowledge_spaces_tenant_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_knowledge_spaces_tenant_id ON public.knowledge_spaces USING btree (tenant_id);


--
-- Name: idx_org_ext_auth_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_org_ext_auth_status ON public.org_ext USING btree (auth_status);


--
-- Name: idx_org_ext_tenant_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_org_ext_tenant_id ON public.org_ext USING btree (tenant_id);


--
-- Name: idx_refresh_tokens_expires_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_refresh_tokens_expires_at ON public.refresh_tokens USING btree (expires_at);


--
-- Name: idx_refresh_tokens_token_hash; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_refresh_tokens_token_hash ON public.refresh_tokens USING btree (token_hash);


--
-- Name: idx_refresh_tokens_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_refresh_tokens_user_id ON public.refresh_tokens USING btree (user_id);


--
-- Name: idx_sknp_phone; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sknp_phone ON public.smartknora_user_profiles USING btree (phone);


--
-- Name: idx_sknp_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sknp_status ON public.smartknora_user_profiles USING btree (status);


--
-- Name: idx_sknp_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sknp_user_id ON public.smartknora_user_profiles USING btree (user_id);


--
-- Name: idx_space_categories_tenant_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_space_categories_tenant_id ON public.space_categories USING btree (tenant_id);


--
-- Name: idx_token_usage_org_created; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_token_usage_org_created ON public.token_usage USING btree (org_id, created_at);


--
-- Name: idx_token_usage_tenant_created; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_token_usage_tenant_created ON public.token_usage USING btree (tenant_id, created_at);


--
-- Name: idx_token_usage_user_created; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_token_usage_user_created ON public.token_usage USING btree (user_id, created_at);


--
-- Name: idx_users_email; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_users_email ON public.users USING btree (email);


--
-- Name: idx_users_ops_admin; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_users_ops_admin ON public.users USING btree (is_ops_admin) WHERE (is_ops_admin = true);


--
-- Name: idx_users_phone; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_users_phone ON public.users USING btree (phone);


--
-- Name: idx_users_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_users_status ON public.users USING btree (status);


--
-- Name: idx_users_username; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX idx_users_username ON public.users USING btree (username) WHERE (username IS NOT NULL);


--
-- Name: knowledge_spaces knowledge_spaces_creator_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.knowledge_spaces
    ADD CONSTRAINT knowledge_spaces_creator_id_fkey FOREIGN KEY (creator_id) REFERENCES public.users(id);


--
-- Name: knowledge_spaces knowledge_spaces_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.knowledge_spaces
    ADD CONSTRAINT knowledge_spaces_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id);


--
-- Name: org_members org_members_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.org_members
    ADD CONSTRAINT org_members_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id);


--
-- Name: org_members org_members_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.org_members
    ADD CONSTRAINT org_members_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: organizations organizations_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.organizations
    ADD CONSTRAINT organizations_owner_id_fkey FOREIGN KEY (owner_id) REFERENCES public.users(id);


--
-- Name: refresh_tokens refresh_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.refresh_tokens
    ADD CONSTRAINT refresh_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: space_members space_members_space_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.space_members
    ADD CONSTRAINT space_members_space_id_fkey FOREIGN KEY (space_id) REFERENCES public.knowledge_spaces(id);


--
-- Name: space_members space_members_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.space_members
    ADD CONSTRAINT space_members_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: token_usage token_usage_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.token_usage
    ADD CONSTRAINT token_usage_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id);


--
-- Name: token_usage token_usage_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.token_usage
    ADD CONSTRAINT token_usage_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: knowledge_spaces; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.knowledge_spaces ENABLE ROW LEVEL SECURITY;

--
-- Name: org_ext; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.org_ext ENABLE ROW LEVEL SECURITY;

--
-- Name: space_categories; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.space_categories ENABLE ROW LEVEL SECURITY;

--
-- Name: knowledge_spaces tenant_isolation; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY tenant_isolation ON public.knowledge_spaces USING (((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)));


--
-- Name: org_ext tenant_isolation; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY tenant_isolation ON public.org_ext USING (((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)));


--
-- Name: space_categories tenant_isolation; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY tenant_isolation ON public.space_categories USING (((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)));


--
-- Name: token_usage tenant_isolation; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY tenant_isolation ON public.token_usage USING (((tenant_id)::text = current_setting('app.current_tenant_id'::text, true)));


--
-- Name: token_usage; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.token_usage ENABLE ROW LEVEL SECURITY;

--
-- PostgreSQL database dump complete
--

\unrestrict XLZcNv5Uc05T9mcl0cFXGPO27PJfolHG3UKapG6pzbXPKswqRNYiwJHW2fXyXjv

